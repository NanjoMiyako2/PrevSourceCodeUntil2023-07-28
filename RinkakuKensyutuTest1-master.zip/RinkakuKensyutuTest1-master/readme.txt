参考画像は以下のリンクからスクリーンショットをいただきました

米津玄師【パプリカ】2020応援ソング 簡単ドレミ楽譜 初心者向け1本指ピアノ - YouTube
https://www.youtube.com/watch?v=n7P9H8JfuTg