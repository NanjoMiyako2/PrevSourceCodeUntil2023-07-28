//Unitのコンストラクタ等

//クラスのコンストラクタ関係
//Unitのコンストラクタ
function Unit(unitDiv, typeList, volume){
	this.unitDiv = unitDiv;
	this.typeList = typeList;
	this.volume = volume;
}